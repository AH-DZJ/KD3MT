import argparse
import torch
import torch.nn as nn
import torchvision.transforms as transforms
import os
from models import fusion_model
from tqdm import tqdm
from PIL import Image
import numpy as np
from matplotlib import pyplot as plt
from torchvision.datasets import ImageFolder
from input_data import ImageDataset
from pytorch_ssim import ssim
import time
from torchvision.utils import save_image,make_grid

os.environ["CUDA_VISIBLE_DEVICES"] = "0"
torch.cuda.set_device(0)

parser = argparse.ArgumentParser()
parser.add_argument("--infrared_dataroot", default="./1/", type=str)
parser.add_argument("--visible_dataroot", default="./2/", type=str)
parser.add_argument("--batch_size", type=int, default=1)
parser.add_argument("--output_root", default="./outputs/", type=str)
parser.add_argument("--image_size", type=int, default=[128, 128])
parser.add_argument("--epoch", type=int, default=1)
parser.add_argument("--lr", type=float, default=0.0001)
parser.add_argument("--checkpoint_dir", type=str, default="checkpoints/")


def feature_imshow(inp, title=None):
    """Imshow for Tensor."""
    inp = inp.detach().numpy().transpose((1, 2, 0))
    mean = np.array([0.5, 0.5, 0.5])
    std = np.array([0.5, 0.5, 0.5])
    inp = std * inp + mean
    inp = np.clip(inp, 0, 1)
    plt.imshow(inp)
    if title is not None:
        plt.title(title)
    plt.pause(0.001)  # pause a bit so that plots are updated


if __name__ == "__main__":
    opt = parser.parse_args()
    if not os.path.exists(opt.checkpoint_dir):
        os.makedirs(opt.checkpoint_dir)
    device = torch.device('cuda:0')
    if not os.path.exists(opt.output_root):
        os.makedirs(opt.output_root)
    net = fusion_model.Fusion_HDC_NODWT_NOSCNet().to(device)
    net.load_state_dict(torch.load("./checkpoints/Fusion_HDC_NODWT_NOSCNet_MEDICAL_mse.pth"))
    net.eval()
    print(net)
    transform = transforms.Compose([
        #transforms.Resize(opt.image_size),
        transforms.ToTensor()])
    with torch.no_grad():
        for i in range(14,74):
            start = time.time()
            index = i + 1
            infrared = Image.open(opt.infrared_dataroot + str(index) + '.jpg').convert("RGB")
            infrared = transform(infrared).unsqueeze(0)
            visible = Image.open(opt.visible_dataroot + str(index) + '.jpg').convert("RGB")
            visible = transform(visible).unsqueeze(0)
            infrared = infrared.to(device)
            visible = visible.to(device)
            # fused_img = net(infrared,visible)
            fused_img1= net(infrared[:,0:1,:,:] , visible[:,0:1,:,:])
            fused_img2 = net(infrared[:, 1:2, :, :], visible[:, 1:2, :, :])
            fused_img3 = net(infrared[:, 2:3, :, :], visible[:, 2:3, :, :])
            fused_img = torch.cat([torch.cat([fused_img1,fused_img2],dim=1),fused_img3],dim=1)
            save_image(fused_img.cpu(), os.path.join(opt.output_root, str(index) + ".jpg"))
            end = time.time()
            print('consume time:',end-start)