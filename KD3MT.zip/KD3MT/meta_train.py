import argparse
import torch
import torch.nn as nn
import torchvision.transforms as transforms
import os
import numpy as np
from models import fusion_model
from tqdm import tqdm
from PIL import Image
from torchvision.datasets import ImageFolder
import time
import torch.nn.functional as F
from input_data import ImageDataset
from pytorch_ssim import ssim,gradient, SSIM
from network_swinfusion1 import SwinFusion
os.environ["CUDA_VISIBLE_DEVICES"] = "0"
torch.cuda.set_device(0)
torch.set_num_threads(6)
from torchvision.utils import save_image
parser = argparse.ArgumentParser()
parser.add_argument("--infrared_dataroot", default="D:/dzs/shujuji/CT_MRI/crop_images/train_ct/", type=str)  #输入有点问题，需要红外和可见光数据个文件夹的名字一样比如/./infrared和/./visible,下面的文件夹名都为1
parser.add_argument("--visible_dataroot", default="D:/dzs/shujuji/CT_MRI/crop_images/train_mri/", type=str)
parser.add_argument("--fused_dataroot", default="D:/dzs/shujuji/CT_MRI/crop_images/F_Swin/", type=str)
parser.add_argument("--batch_size", type=int, default=1)
parser.add_argument("--image_size", type=int, default=[64, 64])
parser.add_argument("--down_size", type=int, default=[64, 64])
parser.add_argument("--epoch", type=int, default=1)
parser.add_argument("--lr", type=float, default=0.0001)
parser.add_argument("--checkpoint_dir", type=str, default="checkpoints/")
parser.add_argument('--scale', type=int, default=1, help='scale factor: 1, 2, 3, 4, 8')  # 1 for dn and jpeg car
parser.add_argument('--in_channel', type=int, default=1, help='3 means color image and 1 means gray image')

def tv_loss(x, batch_size=1):
    batch_size = x.shape[0]
    c_x = x.shape[1]
    h_x = x.shape[2]
    w_x = x.shape[3]
    count_h = x[:, :, 1:, :].size(1) * x[:, :, 1:, :].size(2) * x[:, :, 1:, :].size(3)
    count_w = x[:, :, :, 1:].size(1) * x[:, :, :, 1:].size(2) * x[:, :, :, 1:].size(3)
    h_tv = torch.pow((x[:, :, 1:, :] - x[:, :, :h_x - 1, :]), 2).sum()
    w_tv = torch.pow((x[:, :, :, 1:] - x[:, :, :, :w_x - 1]), 2).sum()
    return h_tv / count_h + w_tv / count_w

if __name__ == "__main__":
    opt = parser.parse_args()
    if not os.path.exists(opt.checkpoint_dir):
        os.makedirs(opt.checkpoint_dir)
    #device = torch.device('cuda:0')
    net = fusion_model.Fusion_transformer_Net().cuda()
    net_teacher = SwinFusion(upscale=opt.scale, in_chans=opt.in_channel, img_size=128, window_size=8,
                img_range=1., depths=[6, 6, 6, 6], embed_dim=60, num_heads=[6, 6, 6, 6],
                mlp_ratio=2, upsampler=None, resi_connection='1conv').cuda()
    net_teacher.load_state_dict(torch.load("./checkpoints/10000_E.pth"))
    net_teacher.eval()
    optim = torch.optim.Adam(filter(lambda p: p.requires_grad,net.parameters()),lr=opt.lr)
    train_datasets = ImageDataset(opt.infrared_dataroot, opt.visible_dataroot, opt.image_size, opt.down_size)
    lens = len(train_datasets)
    log_file = './log_dir'
    dataloader = torch.utils.data.DataLoader(train_datasets,batch_size=opt.batch_size,num_workers = 4, shuffle=False, pin_memory=True)
    runloss = 0.
    total_params = sum(p.numel() for p in net.parameters())
    print('total parameters:', total_params)
    for epoch in range(opt.epoch):
        #if (epoch+1) % 5==1:
          #  opt.lr=0.1*opt.lr
        for index, data in enumerate(tqdm(dataloader)):
            CT = data[0].cuda()
            MRI = data[1].cuda()
            #label = data[2].cuda()
            fused_img = net(CT, MRI)
            label_image = net_teacher(CT, MRI)
            # save_image(label_image.cpu(), os.path.join('D:\dzs\shujuji\CT_MRI\crop_images/f_swin/train/', str(index) + ".png"))
            LOSS_SSIM = 1-ssim(fused_img, CT, MRI)
            #LOSS_L1 = nn.L1Loss()
            #LOSS_L1_NORM = LOSS_L1(fused_img, visible)
            # MSE = nn.MSELoss()
            # LOSS_MSE = MSE(fused_img,MRI)+MSE(fused_img,CT)
            #LOSS_TV= tv_loss(fused_img-visible)
            Loss_label = 1-SSIM(fused_img,label_image)
            loss = LOSS_SSIM + Loss_label
            runloss += loss.item()
            print('\nepoch [{}/{}], images [{}/{}], SSIM loss is {:.5}, total loss is  {:.5}, lr: {}'.
                  format(epoch + 1, opt.epoch, (index + 1) * opt.batch_size, lens+1, LOSS_SSIM.item(), loss.item(), opt.lr))
            runloss = 0.
            optim.zero_grad()
            loss.backward()
            optim.step()
        # if (epoch+1)%2==0:
            torch.save(net.state_dict(), './checkpoints/Fusion_ssim_swin.pth'.format(opt.lr, log_file[2:]))