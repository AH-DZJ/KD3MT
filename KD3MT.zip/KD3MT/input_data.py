import os
import torch
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms, utils
import numpy as np
import PIL
from PIL import Image
#from flowlib import read, read_weights_file
from skimage import io, transform
from PIL import Image
import numpy as np
import re

device = 'cuda'


def toString(num):
    string = str(num)
    while (len(string) < 4):
        string = "0" + string
    return string


class ImageDataset(Dataset):

    def __init__(self, infrared_dataroot, visible_dataroot, image_size,down_size):
        """
        looking at the "clean" subfolder for images, might change to "final" later
        root_dir -> path to the location where the "training" folder is kept inside the MPI folder
        """
        self.infrared_dataroot = infrared_dataroot
        self.visible_dataroot=visible_dataroot
        self.image_size = image_size
        self.down_size = down_size
        self.total_image = []

        for item in os.listdir(os.path.join(self.infrared_dataroot)):

            print('It is now processing {} !'.format(item))
            source_img_dir = os.path.join(self.infrared_dataroot, item)
            source_image_list = os.listdir(os.path.join(source_img_dir))
            source_image_list.sort(key=lambda x: str(re.split('\.|\_', x)[1]))
            target_image_dir = os.path.join(self.visible_dataroot, item)
            target_image_list = os.listdir(os.path.join(target_image_dir))
            target_image_list.sort(key=lambda x: str(re.split('\.|\_', x)[1]))
            #print('target_image_list',target_image_list)
            #tmp_image = (target_image_list, source_image_list)
            tmp_len = len(source_image_list) - 1
            for i in range(tmp_len):
                target_img = os.path.join(target_image_dir, target_image_list[i])
                source_img = os.path.join(source_img_dir, source_image_list[i])
                tmp_image = (target_img, source_img)
                self.total_image.append(tmp_image)
        self.lens = len(self.total_image)
        self.transform = transforms.Compose([
            #transforms.CenterCrop(self.image_size),
            # transforms.RandomHorizontalFlip(),
            transforms.ToTensor()])
        # self.transform_1 = transforms.Compose([
        #     transforms.Resize(self.down_size),
            # transforms.RandomHorizontalFlip(),
            # transforms.ToTensor()])

    def __len__(self):
        return self.lens

    def __getitem__(self, i):
        """
        idx must be between 0 to len-1
        assuming flow[0] contains flow in x direction and flow[1] contains flow in y
        """
        image_path1 = self.total_image[i][0]
        image_path2 = self.total_image[i][1]
        # print('image_path is ',image_path1)
        # print('backward_flow_path ',backward_flow_path)
        # print('consistency_path ',consistency_path)
        img_1 = Image.open(image_path1).convert('L')
        img_2 = Image.open(image_path2).convert('L')
        img1 = self.transform(img_1)
        img2 = self.transform(img_2)
        # img3= self.transform_1(img_1)
        # img4 = self.transform_1(img_2)
        # mask is numpy and shape is HXWX3
        # img_flow = Image.fromarray(np.uint8(flow))
        # this is for transpose.
        # [3,400,640] [3,400,640] [3,400,640],[ 2, 400, 640]
        return (img1, img2)
class ImageDataset_1(Dataset):

    def __init__(self, infrared_dataroot, visible_dataroot,fusion_dataroot, image_size):
        """
        looking at the "clean" subfolder for images, might change to "final" later
        root_dir -> path to the location where the "training" folder is kept inside the MPI folder
        """
        self.infrared_dataroot = infrared_dataroot
        self.visible_dataroot=visible_dataroot
        self.fusion_dataroot = fusion_dataroot
        self.image_size = image_size
        self.total_image = []

        for item in os.listdir(os.path.join(self.infrared_dataroot)):

            print('It is now processing {} !'.format(item))
            source_img_dir = os.path.join(self.infrared_dataroot, item)
            source_image_list = os.listdir(os.path.join(source_img_dir))
            source_image_list.sort(key=lambda x: str(re.split('\.|\_', x)[1]))
            target_image_dir = os.path.join(self.visible_dataroot, item)
            target_image_list = os.listdir(os.path.join(target_image_dir))
            target_image_list.sort(key=lambda x: str(re.split('\.|\_', x)[1]))
            fusion_image_dir = os.path.join(self.fusion_dataroot, item)
            fusion_image_list = os.listdir(os.path.join(fusion_image_dir))
            fusion_image_list.sort(key=lambda x: str(re.split('\.|\_', x)[1]))
            #print('target_image_list',target_image_list)
            #tmp_image = (target_image_list, source_image_list)
            tmp_len = len(source_image_list) - 1
            for i in range(tmp_len):
                target_img = os.path.join(target_image_dir, target_image_list[i])
                source_img = os.path.join(source_img_dir, source_image_list[i])
                fusion_img = os.path.join(fusion_image_dir, fusion_image_list[i])
                tmp_image = ( source_img, target_img, fusion_img)
                self.total_image.append(tmp_image)
        self.lens = len(self.total_image)
        # self.transform1 = transforms.Compose([
        #     transforms.CenterCrop(self.image_size)])
        self.transform = transforms.Compose([
            transforms.Resize(self.image_size),
            transforms.ToTensor()])
        self.transform2 = transforms.Compose([
            transforms.ToTensor()])

    def __len__(self):
        return self.lens

    def __getitem__(self, i):
        """
        idx must be between 0 to len-1
        assuming flow[0] contains flow in x direction and flow[1] contains flow in y
        """
        image_path1 = self.total_image[i][0]
        image_path2 = self.total_image[i][1]
        image_path3 = self.total_image[i][2]
        # print('image_path is ',image_path1)
        # print('backward_flow_path ',backward_flow_path)
        # print('consistency_path ',consistency_path)
        img1 = Image.open(image_path1).convert('L')
        img2 = Image.open(image_path2).convert('L')
        img3 = Image.open(image_path3).convert('L')
        # img_pri = self.transform1(img2.copy())
        # img_pet =self.transform1(img2.copy())
        # size = [x for x in range(1, 64) if x % 2 == 0]
        # h = size[random.randint(0, len(size) - 1)]
        # w = size[random.randint(0, len(size) - 1)]
        # h1 = size[random.randint(0, len(size) - 1)]
        # w1 = size[random.randint(0, len(size) - 1)]
        # x_, y_ = random.randint(1, 64), random.randint(1, 64)
        # x1_, y1_ = random.randint(1, 64), random.randint(1, 64)
        # box = (x_, y_, x_ + h, y_ + w)
        # # box1 = (x1_, y1_, x1_ + h1, y1_ + w1)
        # cropImg_pri = img_pri.crop(box)
        # # cropImg_pet = img_pet.crop(box1)
        # pri_cA, (pri_cH, pri_cV, pri_cD) = dwt2(cropImg_pri, 'haar')  # dwt2函数第二个参数指定小波基
        # cropImg_pri = idwt2((pri_cA, (pri_cH * 0, pri_cV * 0, pri_cD * 0)), 'haar')
        # cropImg_pri = Image.fromarray(cropImg_pri)
        # cropImg_pri = cropImg_pri.resize((h, w))
        # cropImg_pet = np.array(cropImg_pet) / 255
        # cropImg_pet = np.clip((np.power(cropImg_pet, random.uniform(1, 4)) * 255), 0, 255)
        # cropImg_pet = Image.fromarray(cropImg_pet)
        # img_pri.paste(cropImg_pri, box)
        # img_pet.paste(cropImg_pet, box1)

        img_2 = self.transform2(img2)
        # img_pri = self.transform(img_pri)
        # img_pet = self.transform(img_pet)
        img_1 = self.transform2(img1)
        # noise=gaussian_noise(np.array(img_1),0.01)
        # img_1= img_1+noise
        # img_1 =  self.transform2(img_1)
        # img1= self.transform(img1)
        img_3 = self.transform2(img3)
        # mask is numpy and shape is HXWX3
        # img_flow = Image.fromarray(np.uint8(flow))
        # this is for transpose.
        # [3,400,640] [3,400,640] [3,400,640],[ 2, 400, 640]
        return (img_1, img_2,img_3)#infrared, infrared_noise,visible, visible_dwt,fusion

if __name__ == "__main__":
    image = ImageDataset()
    print('data lens', len(image))
    dataloader = torch.utils.data.DataLoader(image, batch_size=1)
    for index, item in enumerate(dataloader):
        print(index)
        print(item[0].shape)
        print(item[1].shape)




