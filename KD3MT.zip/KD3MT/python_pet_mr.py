
from matplotlib import pyplot
import xlrd
from matplotlib.ticker import MultipleLocator
import matplotlib.ticker as ticker

#横坐标
# pyplot.subplot(3, 3, 1)
# Fig=['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21',
#      '22','23','24','25','26','27','28','29','30','31','32','33','34','35','36','37','38','39','40','41','42',
#      '43','44','45','46','47','48','49','50','51','52','53','54','55','56','57','58','59','60','61','62','63',
#      '64','65','66','67','68','69','70','71','72','73','74']#纵坐标
# DDcGAN=[32.337,22.659,29.402,25.273,34.623,40.776,35.839,25.804,35.254,34.001,30.302,30.152]
# IFCNN=[39.334,46.012,44.126,32.879,54.547,54.186,52.118,26.839,75.174,71.007,62.812,59.052]
# PMGI=[86.707,78.488,62.976,55.505,85.641,83.974,84.333,45.54,101.024,85.807,81.072,71.515]
# our_method=[50.963,56.757,59.697,44.447,71.783,77.366,67.907,33.564,94.582,83.908,78.229,68.136]
# SDNet=[39.4285,36.6193,44.034,32.4803,46.4373,50.3342,51.9616,30.4609,57.5257,50.5629,48.1231,42.6502]
# U2Fusion=[31.096,37.501,48.591,33.896,56.067,57.573,62.882,33.631,66.03,62.011,57.041,55.624]
# FusionDN=[78.492,62.99,50.99,44.583,68.722,71.031,70.128,35.915,83.205,67.319,66.183,60.431]
#
# #生成折线图：函数polt
# pyplot.plot(Fig,DDcGAN,label='DDcGAN',marker='.',c='b')
# pyplot.plot(Fig,IFCNN,label='IFCNN',marker='1',c='lime')
# pyplot.plot(Fig,PMGI,label='PMGI',marker='o',c='teal')
# pyplot.plot(Fig,our_method,label='our_method',marker='D',c='r')
# pyplot.plot(Fig,SDNet,label='SDNet',marker='s',c='y')
# pyplot.plot(Fig,U2Fusion,label='U2Fusion',marker='v',c='bisque')
# pyplot.plot(Fig,FusionDN,label='FusionDN',marker='^',c='cornflowerblue')
# pyplot.title('EI')
#
# pyplot.subplot(3, 3, 2)
# Fig=['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21',
#      '22','23','24','25','26','27','28','29','30','31','32','33','34','35','36','37','38','39','40','41','42',
#      '43','44','45','46','47','48','49','50','51','52','53','54','55','56','57','58','59','60','61','62','63',
#      '64','65','66','67','68','69','70','71','72','73','74']#纵坐标
# #纵坐标
# DDcGAN=[15.791,19.811,45.754,44.221,39.348,54.195,43.826,53.051,33.125,37.06,33.795,28.323]
# IFCNN=[27.842,40.838,63.59,58.77,57.782,55.537,53.476,64.384,56.761,66.043,59.778,60.451]
# PMGI=[56.549,63.975,71.407,69.322,71.899,70.116,73.149,77.872,63.643,64.199,60.968,58.666]
# our_method=[38.555,56.421,90.962,83.417,79.937,81.088,72.758,91.452,81.792,94.313,86.742,83.211]
# SDNet=[16.408,25.0059,56.6754,55.8031,45.7388,52.4359,50.7396,75.9022,40.1716,45.1622,43.104,42.4633]
# U2Fusion=[19.548,30.925,61.474,53.936,57.391,53.902,64.62,74.329,46.513,53.587,49.721,51.169]
# FusionDN=[48.405,55.096,57.795,54.71,55.386,56.839,58.827,56.52,54.412,52.308,52.978,47.788]
#
# #生成折线图：函数polt
# pyplot.plot(Fig,DDcGAN,label='DDcGAN',marker='.',c='b')
# pyplot.plot(Fig,IFCNN,label='IFCNN',marker='1',c='lime')
# pyplot.plot(Fig,PMGI,label='PMGI',marker='o',c='teal')
# pyplot.plot(Fig,our_method,label='our_method',marker='D',c='r')
# pyplot.plot(Fig,SDNet,label='SDNet',marker='s',c='y')
# pyplot.plot(Fig,U2Fusion,label='U2Fusion',marker='v',c='bisque')
# pyplot.plot(Fig,FusionDN,label='FusionDN',marker='^',c='cornflowerblue')
# pyplot.title('SD')
excel1=xlrd.open_workbook("D:/论文/brain_medical_image_fusion_via_transformer_net/result/DDcGAN.xls")
sheet1 = excel1.sheet_by_index(0)
excel2=xlrd.open_workbook("D:/论文/brain_medical_image_fusion_via_transformer_net/result/IFCNN.xls")
sheet2 = excel2.sheet_by_index(0)
excel3=xlrd.open_workbook("D:/论文/brain_medical_image_fusion_via_transformer_net/result/PMGI.xls")
sheet3 = excel3.sheet_by_index(0)
excel4=xlrd.open_workbook("D:/论文/brain_medical_image_fusion_via_transformer_net/result/Proposed.xls")
sheet4 = excel4.sheet_by_index(0)
excel5=xlrd.open_workbook("D:/论文/brain_medical_image_fusion_via_transformer_net/result/SDNet.xls")
sheet5 = excel5.sheet_by_index(0)
excel6=xlrd.open_workbook("D:/论文/brain_medical_image_fusion_via_transformer_net/result/U2Fusion.xls")
sheet6 = excel6.sheet_by_index(0)
excel7=xlrd.open_workbook("D:/论文/brain_medical_image_fusion_via_transformer_net/result/SwinFusion.xls")
sheet7 = excel7.sheet_by_index(0)
# fpr1=sheet2.col_values(0)
ax=pyplot.gca()
pyplot.subplot(2, 4,1)
Fig=['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21',
     '22','23','24','25','26','27','28','29','30','31','32','33','34','35','36','37','38','39','40','41','42',
     '43','44','45','46','47','48','49','50','51','52','53','54','55','56','57','58','59','60','61','62','63',
     '64','65','66','67','68','69','70','71','72','73','74']#纵坐标
#纵坐标
DDcGAN=sheet1.col_values(0)
IFCNN=sheet2.col_values(0)
PMGI=sheet3.col_values(0)
our_method=sheet4.col_values(0)
SDNet=sheet5.col_values(0)
U2Fusion=sheet6.col_values(0)
SwinFusion=sheet7.col_values(0)
ax=pyplot.gca()
#生成折线图：函数polt
pyplot.plot(Fig,DDcGAN,label='DDcGAN',marker='.',c='b',markevery=2)
pyplot.plot(Fig,IFCNN,label='IFCNN',marker='1',c='lime',markevery=2)
pyplot.plot(Fig,PMGI,label='PMGI',marker='o',c='teal',markevery=2)
pyplot.plot(Fig,SDNet,label='SDNet',marker='s',c='y',markevery=2)
pyplot.plot(Fig,U2Fusion,label='U2Fusion',marker='v',c='bisque',markevery=2)
pyplot.plot(Fig,SwinFusion,label='SwinFusion',marker='^',c='cornflowerblue',markevery=2)
pyplot.plot(Fig,our_method,label='our_method',marker='D',c='r',markevery=2)
ax.xaxis.set_major_locator(MultipleLocator(5))
pyplot.xticks(rotation=90,fontsize=10)
pyplot.title('MI')

pyplot.subplot(2, 4, 2)
Fig=['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21',
     '22','23','24','25','26','27','28','29','30','31','32','33','34','35','36','37','38','39','40','41','42',
     '43','44','45','46','47','48','49','50','51','52','53','54','55','56','57','58','59','60','61','62','63',
     '64','65','66','67','68','69','70','71','72','73','74']#纵坐标
#纵坐标
DDcGAN=sheet1.col_values(1)
IFCNN=sheet2.col_values(1)
PMGI=sheet3.col_values(1)
our_method=sheet4.col_values(1)
SDNet=sheet5.col_values(1)
U2Fusion=sheet6.col_values(1)
SwinFusion=sheet7.col_values(1)
ax=pyplot.gca()
#生成折线图：函数polt
pyplot.plot(Fig,DDcGAN,label='DDcGAN',marker='.',c='b',markevery=2)
pyplot.plot(Fig,IFCNN,label='IFCNN',marker='1',c='lime',markevery=2)
pyplot.plot(Fig,PMGI,label='PMGI',marker='o',c='teal',markevery=2)
pyplot.plot(Fig,SDNet,label='SDNet',marker='s',c='y',markevery=2)
pyplot.plot(Fig,U2Fusion,label='U2Fusion',marker='v',c='bisque',markevery=2)
pyplot.plot(Fig,SwinFusion,label='SwinFusion',marker='^',c='cornflowerblue',markevery=2)
pyplot.plot(Fig,our_method,label='our_method',marker='D',c='r',markevery=2)
ax.xaxis.set_major_locator(MultipleLocator(5))
pyplot.xticks(rotation=90,fontsize=10)
y=r"${Q}^{F}_{AB}$"
pyplot.title(y)

pyplot.subplot(2, 4, 3)
Fig=['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21',
     '22','23','24','25','26','27','28','29','30','31','32','33','34','35','36','37','38','39','40','41','42',
     '43','44','45','46','47','48','49','50','51','52','53','54','55','56','57','58','59','60','61','62','63',
     '64','65','66','67','68','69','70','71','72','73','74']#纵坐标
#纵坐标
DDcGAN=sheet1.col_values(2)
IFCNN=sheet2.col_values(2)
PMGI=sheet3.col_values(2)
our_method=sheet4.col_values(2)
SDNet=sheet5.col_values(2)
U2Fusion=sheet6.col_values(2)
SwinFusion=sheet7.col_values(2)
ax=pyplot.gca()
#生成折线图：函数polt
pyplot.plot(Fig,DDcGAN,label='DDcGAN',marker='.',c='b',markevery=2)
pyplot.plot(Fig,IFCNN,label='IFCNN',marker='1',c='lime',markevery=2)
pyplot.plot(Fig,PMGI,label='PMGI',marker='o',c='teal',markevery=2)
pyplot.plot(Fig,SDNet,label='SDNet',marker='s',c='y',markevery=2)
pyplot.plot(Fig,U2Fusion,label='U2Fusion',marker='v',c='bisque',markevery=2)
pyplot.plot(Fig,SwinFusion,label='SwinFusion',marker='^',c='cornflowerblue',markevery=2)
pyplot.plot(Fig,our_method,label='our_method',marker='D',c='r',markevery=2)
ax.xaxis.set_major_locator(MultipleLocator(5))
pyplot.xticks(rotation=90,fontsize=10)
pyplot.title('MSSIM')

pyplot.subplot(2, 4, 4)
Fig=['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21',
     '22','23','24','25','26','27','28','29','30','31','32','33','34','35','36','37','38','39','40','41','42',
     '43','44','45','46','47','48','49','50','51','52','53','54','55','56','57','58','59','60','61','62','63',
     '64','65','66','67','68','69','70','71','72','73','74']#纵坐标
#纵坐标
DDcGAN=sheet1.col_values(3)
IFCNN=sheet2.col_values(3)
PMGI=sheet3.col_values(3)
our_method=sheet4.col_values(3)
SDNet=sheet5.col_values(3)
U2Fusion=sheet6.col_values(3)
SwinFusion=sheet7.col_values(3)
ax=pyplot.gca()
#生成折线图：函数polt
pyplot.plot(Fig,DDcGAN,label='DDcGAN',marker='.',c='b',markevery=2)
pyplot.plot(Fig,IFCNN,label='IFCNN',marker='1',c='lime',markevery=2)
pyplot.plot(Fig,PMGI,label='PMGI',marker='o',c='teal',markevery=2)
pyplot.plot(Fig,SDNet,label='SDNet',marker='s',c='y',markevery=2)
pyplot.plot(Fig,U2Fusion,label='U2Fusion',marker='v',c='bisque',markevery=2)
pyplot.plot(Fig,SwinFusion,label='SwinFusion',marker='^',c='cornflowerblue',markevery=2)
pyplot.plot(Fig,our_method,label='our_method',marker='D',c='r',markevery=2)
ax.xaxis.set_major_locator(MultipleLocator(5))
pyplot.xticks(rotation=90,fontsize=10)
pyplot.title('PC')

pyplot.subplot(2, 4, 5)
Fig=['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21',
     '22','23','24','25','26','27','28','29','30','31','32','33','34','35','36','37','38','39','40','41','42',
     '43','44','45','46','47','48','49','50','51','52','53','54','55','56','57','58','59','60','61','62','63',
     '64','65','66','67','68','69','70','71','72','73','74']#纵坐标
#纵坐标
DDcGAN=sheet1.col_values(4)
IFCNN=sheet2.col_values(4)
PMGI=sheet3.col_values(4)
our_method=sheet4.col_values(4)
SDNet=sheet5.col_values(4)
U2Fusion=sheet6.col_values(4)
SwinFusion=sheet7.col_values(4)
ax=pyplot.gca()
#生成折线图：函数polt
pyplot.plot(Fig,DDcGAN,label='DDcGAN',marker='.',c='b',markevery=2)
pyplot.plot(Fig,IFCNN,label='IFCNN',marker='1',c='lime',markevery=2)
pyplot.plot(Fig,PMGI,label='PMGI',marker='o',c='teal',markevery=2)
pyplot.plot(Fig,SDNet,label='SDNet',marker='s',c='y',markevery=2)
pyplot.plot(Fig,U2Fusion,label='U2Fusion',marker='v',c='bisque',markevery=2)
pyplot.plot(Fig,SwinFusion,label='SwinFusion',marker='^',c='cornflowerblue',markevery=2)
pyplot.plot(Fig,our_method,label='our_method',marker='D',c='r',markevery=2)
ax.xaxis.set_major_locator(MultipleLocator(5))
pyplot.xticks(rotation=90,fontsize=10)
pyplot.title('VIF')

pyplot.subplot(2, 4, 6)
Fig=['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21',
     '22','23','24','25','26','27','28','29','30','31','32','33','34','35','36','37','38','39','40','41','42',
     '43','44','45','46','47','48','49','50','51','52','53','54','55','56','57','58','59','60','61','62','63',
     '64','65','66','67','68','69','70','71','72','73','74']#纵坐标
#纵坐标
DDcGAN=sheet1.col_values(5)
IFCNN=sheet2.col_values(5)
PMGI=sheet3.col_values(5)
our_method=sheet4.col_values(5)
SDNet=sheet5.col_values(5)
U2Fusion=sheet6.col_values(5)
SwinFusion=sheet7.col_values(5)
ax=pyplot.gca()
#生成折线图：函数polt
pyplot.plot(Fig,DDcGAN,label='DDcGAN',marker='.',c='b',markevery=2)
pyplot.plot(Fig,IFCNN,label='IFCNN',marker='1',c='lime',markevery=2)
pyplot.plot(Fig,PMGI,label='PMGI',marker='o',c='teal',markevery=2)
pyplot.plot(Fig,SDNet,label='SDNet',marker='s',c='y',markevery=2)
pyplot.plot(Fig,U2Fusion,label='U2Fusion',marker='v',c='bisque',markevery=2)
pyplot.plot(Fig,SwinFusion,label='SwinFusion',marker='^',c='cornflowerblue',markevery=2)
pyplot.plot(Fig,our_method,label='our_method',marker='D',c='r',markevery=2)
ax.xaxis.set_major_locator(MultipleLocator(5))
pyplot.xticks(rotation=90,fontsize=10)
y=r"${Q}_{EP}$"
pyplot.title(y)

pyplot.subplot(2, 4, 7)
Fig=['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21',
     '22','23','24','25','26','27','28','29','30','31','32','33','34','35','36','37','38','39','40','41','42',
     '43','44','45','46','47','48','49','50','51','52','53','54','55','56','57','58','59','60','61','62','63',
     '64','65','66','67','68','69','70','71','72','73','74']#纵坐标
#纵坐标
DDcGAN=sheet1.col_values(6)
IFCNN=sheet2.col_values(6)
PMGI=sheet3.col_values(6)
our_method=sheet4.col_values(6)
SDNet=sheet5.col_values(6)
U2Fusion=sheet6.col_values(6)
SwinFusion=sheet7.col_values(6)
ax=pyplot.gca()
#生成折线图：函数polt
pyplot.plot(Fig,DDcGAN,label='DDcGAN',marker='.',c='b',markevery=2)
pyplot.plot(Fig,IFCNN,label='IFCNN',marker='1',c='lime',markevery=2)
pyplot.plot(Fig,PMGI,label='PMGI',marker='o',c='teal',markevery=2)
pyplot.plot(Fig,SDNet,label='SDNet',marker='s',c='y',markevery=2)
pyplot.plot(Fig,U2Fusion,label='U2Fusion',marker='v',c='bisque',markevery=2)
pyplot.plot(Fig,SwinFusion,label='SwinFusion',marker='^',c='cornflowerblue',markevery=2)
pyplot.plot(Fig,our_method,label='our_method',marker='D',c='r',markevery=2)
ax.xaxis.set_major_locator(MultipleLocator(5))
pyplot.title('UIQI')
# tick_spacing = 5
# pyplot.xaxis.set_major_locator(ticker.MultipleLocator(tick_spacing))
pyplot.xticks(rotation=90,fontsize=10)
pyplot.legend(loc='right', bbox_to_anchor=(1.8,0.5),borderaxespad = 1,fontsize='larger',ncol=1,frameon=True,shadow=True,labelspacing=2)

pyplot.show()
#pyplot.savefig('G:/dzs/CBAM_CNN_paper/图/EN.png',dpi=500,bbox_inches = 'tight')